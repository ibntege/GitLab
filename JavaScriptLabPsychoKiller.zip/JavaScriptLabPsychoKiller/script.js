const lyrics = [
    { time: 0, text: "Introduction - David Byrne" },
    { time: 34.5, text: "I can't seem to face up to the facts" },
    { time: 38.2, text: "I'm tense and nervous and I can't relax" },
    { time: 42.3, text: "I can't sleep because my bed's on fire" },
    { time: 47, text: "Don't touch me I'm a real live wire" },
    { time: 51.5, text: "Psycho Killer, qu'est-ce que c'est?" },
    { time: 55.2, text: "Fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa better" },
    { time: 59.8, text: "Run, run, run, run, run, run, run away" },
    { time: 66, text: " Ohhhh ay-ya-ya-ya-ya-ya, ooh" },
    
    { time: 80.5, text: "You start a conversation, you can't even finish it" },
    { time: 84.3, text: "You're talking a lot, but you're not saying anything" },
    { time: 88.5, text: "When I have nothing to say, my lips are sealed" },
    { time: 92.7, text: "Say something once, why say it again?" },
    { time: 97.2, text: "Psycho Killer" },
    { time: 99.8, text: "Qu'est-ce que c'est?" },
    { time: 101.3, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
    { time: 105.8, text: "Run, run, run, run, run, run, run away" },
    { time: 112, text: " Ohhhh ooh oh" },
    { time: 114, text: "Psycho Killer" },
    { time: 116.3, text: "Qu'est-ce que c'est?" },
    { time: 117.9, text: "Fa-fa-fa-fa, fa-fa-fa-fa-fa-fa, better" },
    { time: 122.7, text: "Run, run, run, run, run, run, run away" },
    { time: 128.9, text: " Ohhhh ay-ya-ya-ya-ya-ya, ooh" },
    { time: 135.5, text: "Ce que j'ai fait, ce soir-là" },
    
    { time: 143.5, text: "Ce que j'ai fait, ce soir-là" },
    
    { time: 152, text: "Réalisant mon espoir" },
    { time: 156, text: "Je me lance vers la gloire, okaaaaaaaaaay" },
    { time: 164, text: "Yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah, yeah"},
    { time: 168.7, text: "We are vain and we are blind"},
    { time: 172.7, text: "I hate people when they're not polite"},
    { time: 177.3, text: "Psycho Killer"},
    { time: 179.6, text: "Qu'est-ce que c'est?" },
    { time: 181, text: "Fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa fa better" },
    { time: 186.3, text: "Run, run, run, run, run, run, run away" },
    { time: 192, text: " Ohhhh ay-ya-ya-ya-ya-ya, ooh" },
];

let currentLyricIndex = 0;
const audio = document.getElementById("audio");
const lyricElement = document.getElementById("lyric");

audio.addEventListener("play", () => {
    setInterval(displayLyrics, 100); 
});

function displayLyrics() {
    const currentTime = audio.currentTime;
    if (
        currentLyricIndex < lyrics.length &&
        currentTime >= lyrics[currentLyricIndex].time
    ) {
        lyricElement.textContent = lyrics[currentLyricIndex].text;
        currentLyricIndex++;
    }
}