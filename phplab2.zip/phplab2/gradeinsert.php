<!DOCTYPE html>
<html lang="en">
<head>
<script src="https://cdn.tailwindcss.com"></script>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Grade Insert</title>
</head>
<div class="max-w-2xl mx-auto mt-10 p-6 border border-gray-300 rounded-lg bg-white shadow">
<body class="bg-gray-300 text-center">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "itgrades";
$course = "INTE 240";
$grade = "A";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO inte (course, grade)
VALUES ('$course', '$grade')";
if ($conn->query($sql) === TRUE) {
echo "<p class='text-green-600  text-2xl '>New record created successfully</p>";
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>   
</body>
</div>
</html>