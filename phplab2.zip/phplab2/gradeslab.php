<!DOCTYPE html>
<html lang="en">
<head>
<script src="https://cdn.tailwindcss.com"></script>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IT Grades</title>
</head>
<div class="max-w-2xl mx-auto mt-10 p-6 border border-gray-300 rounded-lg bg-white shadow">

<body class= "mx-auto text-center bg-gray-200 p-10" >
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "DROP Database if EXISTS itgrades;"; 
if ($conn->query($sql) === TRUE) {
    echo "<p class= 'text-red-500'>Step 1: Database Deleted successfully <br/></p>";
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
$sql = "Create Database itgrades;";
if ($conn->query($sql) === TRUE) {
echo "<p class='text-green-500'>Step 2: itgrades created successfully <br></p>";
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql = "CREATE TABLE `itgrades`.`inte` (`id` INT NOT NULL AUTO_INCREMENT ,
`course` VARCHAR(25) NOT NULL , `grade` VARCHAR(3) NOT NULL , PRIMARY KEY (`id`))
ENGINE = InnoDB;";
if ($conn->query($sql) === TRUE) {
echo "<p class='text-green-500'>Step 3: inte Table created successfully <br/></p>";
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

</body>
</div>
</html>