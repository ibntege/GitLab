<!DOCTYPE html>
<html lang="en">
<head>
<script src="https://cdn.tailwindcss.com"></script>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Grades for Courses</title>
</head>
<body class="bg-gray-200 font-sans">
  <div class="max-w-2xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-md">
    <h1 class="text-2xl font-bold mb-4 text-center text-gray-700">Grade Results
    </h1>
    <div class="text-gray-800 text-sm space-y-2">
 <div>       
<h2 class= "bg-gray-200 text-xl mx-auto"> The following grades are in the System:<br/>
</h2>
</div>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "itgrades";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT course, grade FROM inte;";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo $row["course"]. " --- ". $row["grade"]. "<br>";
}
} else {
echo "There are no grades currently in the system";
}
$conn->close();
?>
</body>
</html>